//
//  SearchContainerView.swift
//  nonso
//
//  Created by Rita Marrano on 20/11/22.
//

import SwiftUI

struct SearchContainerView: View {
    
    private let searchStrings: [String] = []
    @State private var searchText : String = ""

    var body: some View {
        ScrollView {
            SearchBar(text: $searchText, placeholder: "Search")
            PostGridView(posts: MockData().posts)
        }
    }
}

struct SearchView_Previews: PreviewProvider {
    static var previews: some View {
        SearchContainerView()
    }
}
