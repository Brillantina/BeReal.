//
//  nonsoApp.swift
//  nonso
//
//  Created by Rita Marrano on 20/11/22.
//

import SwiftUI

@main
struct nonsoApp: App {
    let persistenceController = PersistenceController.shared

    var body: some Scene {
        WindowGroup {
            RootContainerView()
                .environment(\.managedObjectContext, persistenceController.container.viewContext)
        }
    }
}
