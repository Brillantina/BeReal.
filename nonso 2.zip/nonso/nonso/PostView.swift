//
//  PostView.swift
//  nonso
//
//  Created by Rita Marrano on 20/11/22.
//

import SwiftUI

struct PostView: View {
    
    let post: Post
    let screenWidth: CGFloat
    
    var body: some View {
        VStack(alignment: .leading, spacing: 25) {
            
            //Post info.
                HStack {
                    Image(post.user.userImage)
                        .resizable()
                        .cornerRadius(20)
                        .frame(width: 40, height: 40)
                        .padding(.leading, 10)


                    VStack(alignment: .leading) {
                        Text(post.user.userName)
                            .font(.body)
                            .fontWeight(.bold)
                            .foregroundColor(.white)
                        
                        Text("37 min ")
                            .foregroundColor(.gray)
                            .font(.subheadline)
                            
                    }

                    Spacer()
                    Image(systemName: "ellipsis")
                        .padding(.trailing, 10)
                }
                .frame(height: 25)
           
            VStack(alignment: .leading, spacing: 5){
                //Image.
                Image(post.postImage)
                    .resizable()
                    .scaledToFill()
                    .frame(width: 395, height: 450)
                    .cornerRadius(16)
                    .overlay(
                        Image(post.postImage2)
                            .frame(width: 160, height: 200)
                            .cornerRadius(16)
                            .padding(.horizontal, 10)
                            .position(x:90,y:120)
                        
                    )
                
                Text (post.caption)
                
                    .foregroundColor(.white)
                    .fontWeight(.bold)
            }
//                .resizable()
//                .scaledToFill()
//                .cornerRadius(16)
//                .frame(width: screenWidth, height: screenWidth * 1.1)
//                .clipped()
            
            //Operations menu.
//            HStack {
//                Image(systemName: "heart")
//                    .resizable()
//                    .frame(width: 15, height: 15)
//                    .padding(5)
//                    .padding(.leading, 10)
//                Image(systemName: "bubble.right")
//                    .resizable()
//                    .frame(width: 15, height: 15)
//                    .padding(5)
//                Image(systemName: "paperplane")
//                    .resizable()
//                    .frame(width: 15, height: 15)
//                    .padding(5)
//                Spacer()
//                Image(systemName: "bookmark")
//                    .resizable()
//                    .frame(width: 15, height: 18)
//                    .padding(5)
//                    .padding(.trailing, 10)
//            }
//            .frame(height: 20)
//            VStack(alignment: .leading, spacing: 0){
//                Group {
//                    Text(post.user.userName)
//                        .font(Font.system(size: 14, weight: .semibold))
//                        + Text(" ")
//                        + Text(post.caption)
//                        .font(Font.system(size: 14))
//                }
//                .padding(.horizontal, 15)
//            }
//            .frame(maxWidth: screenWidth, maxHeight: 60, alignment: .leading)
           
        }
    }
}

struct PostView_Previews: PreviewProvider {
    static var previews: some View {
        GeometryReader { geometry in
            PostView(post: MockData().posts.first!, screenWidth: geometry.size.width).preferredColorScheme(.dark)
        }
    }
}
