//
//  ProfileHeader.swift
//  nonso
//
//  Created by Rita Marrano on 20/11/22.
//

import SwiftUI

struct ProfileHeader: View {
    
    let user: User
    
    var body: some View {
        
        VStack {
            
            HStack {
                
                Spacer()
                
                Image(user.userImage)
                    .resizable()
                    .frame(width: 120, height: 120, alignment: .center)
                    .cornerRadius(60)
                    .clipped()
                    .padding()
                
                Spacer()
                

            }
            
            Text(user.fullName)
                .fontWeight(.bold)
                .foregroundColor(.white)
            
            Text(user.userName)
                .foregroundColor(.white)
                
        }


        
    }
}

struct ProfileHeader_Previews: PreviewProvider {
    static var previews: some View {
        ProfileHeader(user: User(fullName: "Rita",userName: "Brillantina", userImage: "post_18")).preferredColorScheme(.dark)
    }
}
