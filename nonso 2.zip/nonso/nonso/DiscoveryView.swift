//
//  DiscoveryView.swift
//  nonso
//
//  Created by Rita Marrano on 20/11/22.
//

import SwiftUI

struct DiscoveryView: View {
    
    var body: some View {
        
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct DiscoveryView_Previews: PreviewProvider {
    static var previews: some View {
        DiscoveryView()
    }
}
