//
//  ActivityView.swift
//  nonso
//
//  Created by Rita Marrano on 20/11/22.
//

import SwiftUI

struct ActivityView: View {
    
    let activity: Activity
    
    var body: some View {
        HStack {
            Image(activity.usersInContext.first!.userImage)
                .resizable()
                .cornerRadius(20)
                .frame(width: 40, height: 40, alignment: .center)
                .clipped()

            if activity.activity == .liked {
                Text(activity.getUsernames())
                    .font(Font.system(size: 12, weight: .semibold)) +
                    Text(activity.usersInContext.count == 1 ? " reacted your post. " : " and others reacted your post. ")
                    .font(Font.system(size: 12, weight: .medium)) +
                    Text(activity.duration)
                    .font(Font.system(size: 10, weight: .light))
            } else if activity.activity == .comment {
                Text(activity.getUsernames())
                    .font(Font.system(size: 12, weight: .semibold)) +
                    Text(" added a comment: ")
                    .font(Font.system(size: 12, weight: .medium)) +
                    Text((activity.comment))
                    .font(Font.system(size: 12, weight: .semibold)) +
                    Text(" " + activity.duration)
                    .font(Font.system(size: 10, weight: .light))
            }
            else if activity.activity == .suggestFollower {
                Text(activity.getUsernames())
                    .font(Font.system(size: 12, weight: .semibold)) +
                    Text(" your mayBeReal friend ")
                    .font(Font.system(size: 12, weight: .medium)) +
                    Text(activity.duration)
                    .font(Font.system(size: 10, weight: .light))
            }
            else if activity.activity == .newFollower {
                Text(activity.getUsernames())
                    .font(Font.system(size: 12, weight: .semibold)) +
                    Text(" request you. ")
                    .font(Font.system(size: 12, weight: .medium)) +
                    Text(activity.duration)
                    .font(Font.system(size: 10, weight: .light))
            }
            
            Spacer()
            
            if activity.activity == .suggestFollower {
                
                Button(action: {
                    
                }) {
                    HStack {
                        Spacer()
                        Text("Follow")
                            .font(Font.system(size: 14, weight: .semibold))
                            .foregroundColor(.white)
                            .clipped()
                        Spacer()
                    }
                }
                .padding()
                .background(Color.blue)
                .frame(width: 100, height: 30, alignment: .center)
                .clipped()
                .cornerRadius(6)
            } else if activity.activity == .newFollower {
                Button("Add") {
                    print("Follow button clicked.")
                }
                .font(Font.system(size: 14, weight: .semibold))
                .padding()
                .foregroundColor(.primary)
                .cornerRadius(6)
                .overlay(RoundedRectangle(cornerRadius: 6)
                            .stroke(Color.primary, lineWidth: 0.2).frame(height: 28, alignment: .center))
                .frame(width: 100, height: 30, alignment: .center)
            } else {
                Image(activity.post.postImage)
                    .resizable()
                    .cornerRadius(25)
                    .frame(width: 40, height: 40, alignment: .center)
                    .clipped()
            }
        }
        .padding(.horizontal, 15)
        .padding(.vertical, 5)
        .frame(width: UIScreen.main.bounds.width, alignment: .leading)
    }
}

struct LikedActivityView_Previews: PreviewProvider {
    static var previews: some View {
        ActivityView(activity: Activity(activity: .liked,
                                             duration: "5h",
                                        usersInContext: [User(fullName:"axeyked", userName: "axeyked", userImage: "user_2")],
                                             post: Post(user: User(fullName: "Giovanni",userName: "pankajgaikar", userImage: "sample_post") , postImage: "post_18",
                                                        postImage2: "post_17",
                                                        caption: "If any one attempts to haul down the American flag, shoot him on the spot.")))
    }
}

struct LikedActivityView_Previews_Comment: PreviewProvider {
    static var previews: some View {
        ActivityView(activity: Activity(activity: .comment,
                                             duration: "5h",
                                        usersInContext: [User(fullName:"Giovanni",userName: "automatico", userImage: "user_9")],
                                        post: Post(user: User(fullName: "Giovanni", userName: "pankajgaikar", userImage: "sample_post"), postImage: "post_18",
                                                        postImage2: "post_6", caption: "notte prima degli esami"),
                                             comment: "@automatico ❤️🙏🏻"))
    }
}


struct LikedActivityView_Previews_SuggestedFollower: PreviewProvider {
    static var previews: some View {
        ActivityView(activity: Activity(activity: .suggestFollower,
                                             duration: "6h",
                                             usersInContext: [User(fullName:"ciao",userName: "hiker.benn", userImage: "user_18")],
                                             post: Post(user: User(fullName:"ciao",userName: "pankajgaikar", userImage: "sample_post"), postImage: "post_18",
                                                        postImage2: "post_6", caption: "yesssss"),
                                             comment: ""))
    }
}

struct LikedActivityView_Previews_NewFollower: PreviewProvider {
    static var previews: some View {
        ActivityView(activity: Activity(activity: .newFollower,
                                             duration: "18h",
                                        usersInContext: [User(fullName:"ciao",userName: "power_of_shiva_99", userImage: "user_20")],
                                             post: Post(user: User(fullName:"Giovanni",userName: "pankajgaikar", userImage: "sample_post"), postImage: "post_18",
                                                        postImage2: "post_17", caption: "yessssssssss"),
                                             comment: ""))
    }
}

