//
//  User.swift
//  nonso
//
//  Created by Rita Marrano on 20/11/22.
//

import Foundation


struct User: Identifiable {
    var id = UUID()
    let fullName: String
    let userName: String
    let userImage: String
}
