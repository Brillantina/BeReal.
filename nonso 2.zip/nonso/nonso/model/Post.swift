//
//  Post.swift
//  nonso
//
//  Created by Rita Marrano on 20/11/22.
//

import Foundation

struct Post: Identifiable {
    let id = UUID()
    let user: User
    let postImage: String
    let postImage2: String
    let caption: String
}
