//
//  MockData.swift
//  nonso
//
//  Created by Rita Marrano on 20/11/22.
//

import Foundation
import AVFoundation

struct MockData {
    
var posts: [Post] = [
    
    Post(user: User(fullName: "Rita " , userName: "Brillantinaexe", userImage: "user_1"),
         postImage: "post_1",
         postImage2: "post_4",
         caption: "tutt foxx"),
    
    Post(user: User(fullName: "Giuliana  " , userName: "Giuly", userImage: "user_2"),
         postImage: "post_2",
         postImage2: "post_1",
         caption: "il cielo è sempre più blu"),
    
    Post(user: User(fullName: "Antonia " , userName: "Antonomasia", userImage: "user_3"),
         postImage: "post_3",
         postImage2: "post_8",
         caption: "mi lascio dietro degli spazi bianchi"),
    
    Post(user: User(fullName: "Stefano " , userName: "Step", userImage: "4"),
         postImage: "post_4",
         postImage2: "post_7",
         caption: "notte di lacrime e preghiere"),
    
    Post(user: User(fullName: "Giovanni " , userName: "Automatico", userImage: "user_16"),
         postImage: "post_8",
         postImage2: "post_5",
         caption: "questa notte è solo noooostra"),
    
    Post(user: User(fullName: "Alessio " , userName: "IlPiuSimpaticoMarino", userImage: "user_13"),
         postImage: "post_17",
         postImage2: "post_7",
         caption: "follow4follow"),

    Post(user: User(fullName: "Marco " , userName: "guitarBoy", userImage: "user_14"),
         postImage: "post_13",
         postImage2: "post_11",
         caption: "stasera si suona a caesert"),
    
    Post(user: User(fullName: "Pasquale " , userName: "Sp3nko", userImage: "user_12"),
         postImage: "post_9",
         postImage2: "post_8",
         caption: "mi piacciono i treni "),
    
    Post(user: User(fullName: "Alberto " , userName: "AlbertoCr3cs", userImage: "user_16"),
         postImage: "post_10",
         postImage2: "post_5",
         caption: "ogggi baldoria xdxdxd"),
    
    Post(user: User(fullName: "Danilo " , userName: "Dani", userImage: "user_15"),
         postImage: "post_9",
         postImage2: "post_2",
         caption: "o che bela madunina"),
    
    Post(user: User(fullName: "Ester " , userName: "mary3ster", userImage: "user_13"),
         postImage: "post_10",
         postImage2: "post_3",
         caption: "e pensaaa sei più bella adesso mentre sfiorisci"),
    
    Post(user: User(fullName: "Panco " , userName: "Pinco", userImage: "user_7"),
         postImage: "post_4",
         postImage2: "post_5",
         caption: "io cerco un centro di gravità almeno momentaneo"),

    Post(user: User(fullName: "Mattia " , userName: "LaBadessa", userImage: "user_16"),
         postImage: "post_8",
         postImage2: "post_11",
         caption: "ti vedo indecisa tra spinello e pisello"),
    
    
    ]
    var activity: [Activity] = [
        Activity(activity: .liked,
                 duration: "15m",
                 usersInContext: [User(fullName: "Giuliana ", userName: "Giuly", userImage: "user_8"), User(fullName: "Stefano ",userName: "Step", userImage: "user_7")],
                 post: Post(user: User(fullName: "Giovanni ",userName: "automatico", userImage: "user_16"), postImage: "post_18", postImage2: "post_13", caption: "il cielo è sempre più blu")),
        
        Activity(activity: .comment,
                 duration: "2h",
                 usersInContext: [User(fullName: "Giovanni ", userName: "Automatico", userImage: "user_9"), User(fullName: "Stefano ",userName: "Step", userImage: "user_7")],
                 post: Post(user: User(fullName: "Giovanni ",userName: "automatico", userImage: "user_16"), postImage: "post_11", postImage2: "post_9", caption: "tutt fox")),
        
        Activity(activity: .suggestFollower,
                 duration: "23min",
                 usersInContext: [User(fullName: "Giovanni ", userName: "Automatico", userImage: "user_9"), User(fullName: "Stefano ",userName: "Step", userImage: "user_7")],
                 post: Post(user: User(fullName: "Giovanni ",userName: "automatico", userImage: "user_16"), postImage: "post_11", postImage2: "post_9", caption: "tutt fox")),

        Activity(activity: .newFollower,
                 duration: "1h",
                 usersInContext: [User(fullName: "Giovanni ", userName: "Automatico", userImage: "user_9"), User(fullName: "Stefano ",userName: "Step", userImage: "user_7")],
                 post: Post(user: User(fullName: "Giovanni ",userName: "automatico", userImage: "user_16"), postImage: "post_11", postImage2: "post_9", caption: "tutt fox")),
        
       ]
    }
