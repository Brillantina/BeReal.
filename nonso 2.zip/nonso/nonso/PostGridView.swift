//
//  PostGridView.swift
//  nonso
//
//  Created by Rita Marrano on 20/11/22.
//

import SwiftUI

struct PostGridView: View {
    
    let posts: [Post]
    private let columns = [
        GridItem(.flexible()),
        GridItem(.flexible()),
        GridItem(.flexible()),
        GridItem(.flexible()),
        GridItem(.flexible()),
        GridItem(.flexible()),
        GridItem(.flexible())
    ]
    
    var body: some View {
      Rectangle()
            .frame(width: 360, height: 140)
            .cornerRadius(16)
            .foregroundColor(.gray)
            .overlay(
                LazyVGrid(columns: columns, spacing: 2){
                    
                    ForEach(posts) {
                        Image($0.postImage)
                            .resizable()
                            .aspectRatio( contentMode: .fill)
                            .frame(width: 35, height: 50)
                            .clipShape(Rectangle())
                            .overlay(Rectangle()
                                .stroke(Color("fig"),lineWidth: 1))
                            .cornerRadius(6)
                    }
                }
            )
        }
    }


struct PostGridView_Previews: PreviewProvider {
    static var previews: some View {
        PostGridView(posts: MockData().posts)
    }
}
