//
//  TimeLineContainerView.swift
//  nonso
//
//  Created by Rita Marrano on 20/11/22.
//

import SwiftUI

struct TimeLineContainerView: View {
    
    var body: some View {
        NavigationView {
            ScrollView(.vertical, showsIndicators: false) {
                ScrollView(.horizontal, showsIndicators: false) {
                   
                }
                ForEach(MockData().posts) {
                    PostView(post: $0, screenWidth: UIScreen.main.bounds.size.width)
                }
            }
            .navigationBarTitle("", displayMode: .inline)
            .toolbar(content: {
               
                ToolbarItem(placement: .navigationBarLeading) {
                    HStack {
                        NavigationLink(destination: FriendsContainerView()) {
                            
                            Image(systemName: "person.2.fill")
                                .foregroundColor(.white)
//                                .renderingMode(.original)
//                                .resizable()
//                                .frame(width: 25, height: 25)
                        }

                    }
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    HStack {
                        NavigationLink(destination: ActivityContainerView()) {
                            Image(systemName: "heart.fill")
                                .foregroundColor(.white)
                            
                            
//                                .renderingMode(.original)
//                                .resizable()
//                                .frame(width: 25, height: 25)
                        }

                    }
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    HStack {
                        NavigationLink(destination: ProfileContainerView()) {
                            Image(systemName: "person.crop.circle")
                                .foregroundColor(.white)
                            
                            
//                                .renderingMode(.original)
//                                .resizable()
//                                .frame(width: 25, height: 25)
                        }

                    }
                }
            })
        }
    }
}

struct TimeLineView_Previews: PreviewProvider {
    static var previews: some View {
        TimeLineContainerView().preferredColorScheme(.dark)
    }
}
